# FFmpeg builds on OSX 10.13 with Xcode 10.0

## Get Source

- You can clone the git repo and checkout the tag of the release you'd like
  - `git clone https://github.com/FFmpeg/FFmpeg.git`
- Or, you can download the release tarball you'd like to build at [FFmpeg github releases](https://github.com/FFmpeg/FFmpeg/releases)
  - If you download a tarball you can use Finder or `tar zxvf {path to tarball}` to extract it

## Prep the directory structure

- Once inside of the FFmpeg folder, create a `install_dir` and a `build_dir` folder side-by-side
  - `mkdir install_dir build_dir`

## Install dependencies

- Xcode 10.0 removed `nasm`/`yasm` for some reason
  - I recommend installing `nasm` through homebrew
    - It can be removed when you are finished

## Start the build

- First, `cd build_dir` so we are in the proper directory
- Run the following command: `../configure --prefix=../install_dir --enable-shared --disable-static --disable-debug --disable-programs --disable-doc --disable-autodetect --disable-avdevice --disable-swresample --disable-postproc --disable-avfilter && make -j9 && make install`
  - This will `configure`, `make`, and `make install` with all of the appropriate options
  - `make install` output can be located in the `$PREFIX` directory (`../install_dir`)

## Prep dylibs for Vision

- First, `cd ../install_dir/lib` so we are in the proper directory
- Run the `{path to p4 branch}/Vision/Output/mac/Frameworks/setup_ffmpeg.sh` script
  - This replaces the internal pathing of the dylibs to be `@rpath`
- Remove all FFmpeg `pkgconfig` and `dylib`'s from `{path to p4 branch}/Vision/Output/mac/Frameworks/`
- Lastly, `cp -a * {path to p4 branch}/Vision/Output/mac/Frameworks/`

## Prep includes for Vision

- First, `cd ..` so we are in the proper directory
- `rm -rf {path to p4 branch}/Vision/Source/External/ffmpeg-{old version}`
- `mkdir {path to p4 branch}/Vision/Source/External/ffmpeg-{new version}`
- `cp -a include {path to p4 branch}/Vision/Source/External/ffmpeg-{new version}/`

## Test changes

- First, perform a clean build
- `cd {path to p4 branch}/Vision/Output/mac/debug`
- `lldb ./Vision.app/Contents/MacOS/Vision`
- Type `r` to run
  - if it crashes at launch, something failed
  - if it launches at all, it succeeded
- `open .` to launch a finder window in the `$CWD`
- Double-click `Vision.app`
  - if it crashes at launch, something failed
  - if it launches at all, it succeeded
