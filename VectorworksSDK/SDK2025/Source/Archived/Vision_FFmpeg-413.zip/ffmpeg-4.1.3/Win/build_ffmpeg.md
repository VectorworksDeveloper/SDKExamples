# FFmpeg builds on Windows 10 with Visual Studio 2017

## Get Source

- You can clone the git repo and checkout the tag of the release you'd like
  - `git clone https://github.com/FFmpeg/FFmpeg.git`
- Or, you can download the release tarball you'd like to build at [FFmpeg github releases](https://github.com/FFmpeg/FFmpeg/releases)
  - If you download a tarball you can use 7-Zip or `tar zxvf {path to tarball}` to extract it

## Prep the directory structure

- At the root of the C drive, create a `ffmpeg_inst` folder
  - `mkdir ffmpeg_inst`
  - This needs to be at the drive root and a short name because path lengths may be too long for windows to handle otherwise
- Once inside of the FFmpeg folder, create a `build_dir` folder
  - `mkdir build_dir`

## Install dependencies

- Install visual studio 2017
  - visual c++ core features
  - vc++ 2017 version 15.5 v14.12 toolset
  - windows 10 sdk 10.0.15063.0 for desktop c++
- Download yasm and place in path
- Install mingw, only msys-base-bin is required

## Start the build

- Run the following command from cmd.exe: `"C:\Program Files (x86)\Microsoft Visual Studio\2017\Professional\VC\Auxiliary\Build\vcvarsall.bat" x64 10.0.15063.0 && C:\MinGW\msys\1.0\msys.bat`
  - This will set up the build environment and launch a mingw shell
- In the mingw shell, `cd build_dir` so we are in the proper directory
- Run the following command from mingw: `export PATH="C:\Program Files (x86)\Microsoft Visual Studio\2017\Professional\VC\Tools\MSVC\14.16.27023\bin\Hostx64\x64":$PATH`
  - This will set the correct environment pathing
- Run the following command from mingw: `../configure --target-os=win64 --arch=x86_64 --toolchain=msvc --enable-shared --disable-static --disable-debug --prefix=/c/ffmpeg_inst --disable-programs --disable-doc --disable-autodetect --disable-avdevice --disable-swresample --disable-postproc --disable-avfilter`
  - This will `configure` with all of the appropriate options
- Run the following command from mingw: `make -j9`
- Run the following command from mingw: `make install`
  - `make install` output can be located in the `$PREFIX` directory (`/c/ffmpeg_inst`)

## Prep dlls for Vision

- First, `cd ../install_dir/bin` so we are in the proper directory
- Remove all FFmpeg `dll`'s from `{path to p4 branch}/Vision/Output/win/Common/`
- Remove all FFmpeg `lib`'s from `{path to p4 branch}/Vision/Output/win/lib/`
- Lastly, `cp -a *.dll {path to p4 branch}/Vision/Output/win/Common/ && cp -a *.lib {path to p4 branch}/Vision/Output/win/lib/`

## Prep includes for Vision

- First, `cd ..` so we are in the proper directory
- `rm -rf {path to p4 branch}/Vision/Source/External/ffmpeg-{old version}`
- `mkdir {path to p4 branch}/Vision/Source/External/ffmpeg-{new version}`
- `cp -a include {path to p4 branch}/Vision/Source/External/ffmpeg-{new version}/`

## Test changes

- First, perform a clean build
- Press `F5` to run
  - if it crashes at launch, something failed
  - if it launches at all, it succeeded
- Open the output folder in File Explorer
- Double-click `Vision.exe`
  - if it crashes at launch, something failed
  - if it launches at all, it succeeded
